PLUGIN_NAME = 'AmazonCloudWatchCollectdPlugin'
PLUGIN_VERSION = 1.0
NAMESPACE = 'collectd'
